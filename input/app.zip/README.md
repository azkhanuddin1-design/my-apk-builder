# HTML / ZIP → APK builder

Put your web app in `input/app.zip` (or a single `.html` file) and push. GitHub Actions builds a signed,
installable APK and publishes it under **Releases**. Free, works from a phone browser.

Optional files in `input/`:
- `config.json` — `{"name":"My App","package":"com.me.app","version":"1.0","orientation":"auto|portrait|landscape","fullscreen":false}`
- `icon.png` — launcher icon (square, 512x512 recommended)

## Build on your PC instead
Needs JDK 17, Android SDK (set `ANDROID_HOME`), Gradle 8.7+ and `pip install pillow`:

    python tools/prepare.py
    gradle assembleRelease

The APK is at `app/build/outputs/apk/release/app-release.apk`.

## Notes
- The signing key in `keystore/release.jks` is shared by every build in this repo, so new builds update
  the old install. For a public/Play Store app, replace it with your own private key.
- A single-page app with `index.html` at the root of the zip (or one folder deep) works best.
