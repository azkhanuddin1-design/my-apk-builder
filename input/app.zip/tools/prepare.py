#!/usr/bin/env python3
"""Turns input/app.zip (or an .html file) + input/config.json into an Android project.

Writes: app/src/main/assets/www, res/values/{strings,config}.xml, launcher icons, gradle.properties.
"""
import hashlib
import json
import os
import re
import shutil
import sys
import time
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent.parent
INPUT = ROOT / "input"
WWW = ROOT / "app/src/main/assets/www"
RES = ROOT / "app/src/main/res"


def fail(msg):
    print("ERROR:", msg)
    sys.exit(1)


def slugify(s):
    return re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower() or "app"


def find_source():
    if (INPUT / "app.zip").exists():
        return INPUT / "app.zip"
    if INPUT.exists():
        for pattern in ("*.zip", "*.html", "*.htm"):
            found = sorted(INPUT.glob(pattern))
            if found:
                return found[0]
    fail("No input found. Put app.zip (or an .html file) in the input/ folder.")


def safe_extract(zf, dest):
    dest = dest.resolve()
    for m in zf.infolist():
        name = m.filename
        if name.startswith("__MACOSX/") or name.endswith(".DS_Store"):
            continue
        target = (dest / name).resolve()
        if target != dest and not str(target).startswith(str(dest) + os.sep):
            fail("Unsafe path in zip: " + name)
        if m.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(m) as s, open(target, "wb") as d:
            shutil.copyfileobj(s, d)


def locate_index():
    htmls = [p for p in WWW.rglob("*") if p.is_file() and p.suffix.lower() in (".html", ".htm")]
    if not htmls:
        fail("No .html file found in your upload.")
    indexes = [p for p in htmls if p.name.lower() == "index.html"]
    if indexes:
        best = min(indexes, key=lambda p: len(p.relative_to(WWW).parts))
    else:
        best = min(htmls, key=lambda p: (len(p.relative_to(WWW).parts), p.name))
        print("No index.html found; using", best.name)
    root = best.parent
    if root != WWW:  # content lives in a sub-folder: lift it up
        tmp = WWW.parent / "_www_tmp"
        if tmp.exists():
            shutil.rmtree(tmp)
        shutil.move(str(root), str(tmp))
        shutil.rmtree(WWW)
        tmp.rename(WWW)
        best = WWW / best.name
    if best.name != "index.html":
        best.rename(WWW / "index.html")


def load_config(source):
    cfg = {}
    p = INPUT / "config.json"
    if p.exists():
        try:
            cfg = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            fail("config.json is not valid JSON: %s" % e)
    name = str(cfg.get("name") or "").strip() or ("My App" if source.stem == "app" else source.stem)
    name = re.sub(r"\s+", " ", name)[:50]
    slug = slugify(name)
    pkg = str(cfg.get("package") or "").strip().lower()
    if not re.match(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$", pkg):
        if pkg:
            print("Package id '%s' is invalid; generating one." % pkg)
        suffix = re.sub(r"[^a-z0-9]", "", slug) or "app"
        if not suffix[0].isalpha():
            suffix = "app" + suffix
        pkg = "com.appbuilder." + suffix
    orientation = cfg.get("orientation", "auto")
    orientation = {"portrait": "portrait", "landscape": "landscape"}.get(orientation, "unspecified")
    return {
        "name": name,
        "slug": slug,
        "package": pkg,
        "version": str(cfg.get("version") or "1.0")[:20],
        "versionCode": int(cfg.get("versionCode") or (time.time() // 60)),
        "orientation": orientation,
        "fullscreen": bool(cfg.get("fullscreen", False)),
    }


def xml_string(s):
    s = escape(s).replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
    return ("\\" + s) if s[:1] in "@?" else s


def make_icons(cfg):
    from PIL import Image, ImageDraw, ImageFont

    img = None
    candidates = [INPUT / "icon.png"] + [
        WWW / n for n in ("icon.png", "icon-512.png", "icon-192.png", "apple-touch-icon.png")
    ]
    for c in candidates:
        if c.exists():
            try:
                img = Image.open(c).convert("RGBA")
                print("Using icon:", c)
                break
            except Exception:  # noqa: BLE001
                pass
    if img is None:
        h = int(hashlib.md5(cfg["name"].encode()).hexdigest(), 16)
        color = ((h >> 16) % 150 + 40, (h >> 8) % 150 + 40, h % 150 + 40, 255)
        img = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle((0, 0, 511, 511), radius=110, fill=color)
        letter = cfg["name"][:1].upper() or "A"
        try:
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 300)
            except Exception:  # noqa: BLE001
                font = ImageFont.load_default(size=300)
            d.text((256, 266), letter, font=font, fill="white", anchor="mm")
        except Exception:  # noqa: BLE001
            d.ellipse((156, 156, 356, 356), fill="white")
    w, h = img.size
    side = min(w, h)
    img = img.crop(((w - side) // 2, (h - side) // 2, (w - side) // 2 + side, (h - side) // 2 + side))
    for d_name, px in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
        out = RES / ("mipmap-" + d_name)
        out.mkdir(parents=True, exist_ok=True)
        img.resize((px, px), Image.LANCZOS).save(out / "ic_launcher.png")


def main():
    source = find_source()
    print("Source:", source)
    if WWW.exists():
        shutil.rmtree(WWW)
    WWW.mkdir(parents=True)
    if source.suffix.lower() == ".zip":
        with zipfile.ZipFile(source) as zf:
            safe_extract(zf, WWW)
    else:
        shutil.copy(source, WWW / source.name)
    locate_index()
    cfg = load_config(source)
    print("Config:", cfg)

    values = RES / "values"
    values.mkdir(parents=True, exist_ok=True)
    (values / "strings.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        '    <string name="app_name">%s</string>\n</resources>\n' % xml_string(cfg["name"]),
        encoding="utf-8",
    )
    (values / "config.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        '    <bool name="fullscreen">%s</bool>\n</resources>\n' % str(cfg["fullscreen"]).lower(),
        encoding="utf-8",
    )
    (ROOT / "gradle.properties").write_text(
        "org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\n"
        "android.useAndroidX=false\n"
        "android.nonTransitiveRClass=true\n"
        "appId=%s\nappVersionName=%s\nappVersionCode=%d\nappOrientation=%s\n"
        % (cfg["package"], cfg["version"], cfg["versionCode"], cfg["orientation"]),
        encoding="utf-8",
    )
    make_icons(cfg)

    env_file = os.environ.get("GITHUB_ENV")
    if env_file:
        with open(env_file, "a", encoding="utf-8") as f:
            f.write("APP_SLUG=%s\nAPP_NAME=%s\n" % (cfg["slug"], cfg["name"].replace("\n", " ")))
    print("Prepared OK")


if __name__ == "__main__":
    main()
